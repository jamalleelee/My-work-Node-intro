const express = require("express");
const app = express();
const config = require("./config.json");
const path = require("path");
const expressPromiseRouter = require("express-promise-router");
const unhandledError = require("unhandled-error");

app.listen(config.port, () =>{
    console.log(`I can hear you on port http://localhost:${config.port}!`)
});

let errorReporter = unhandledError((err) =>{
    console.error("UNHANDLED ERROR:", err.stack);
});

let state = {
    errorReporter:errorReporter
}

app.use(require("./routes/index.js"));
app.set("views", path.join(__dirname, "views"));
app.set("view engine", "pug");
app.use(express.static(path.join(__dirname, "public")));

let router = expressPromiseRouter();

router.use(express.static(path.join(__dirname, "public")));

router.use(require("./routes/index.js"));

app.use(router);
