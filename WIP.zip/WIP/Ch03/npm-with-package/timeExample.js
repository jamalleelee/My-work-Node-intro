var moment = require('moment');
var momenttz = require('moment-timezone');
console.log(moment().format('MM-DD-YYYY'));
console.log(moment("20110101", "YYYYMMDD").fromNow());

let now = moment();
//console.log(now.tz('America/New_York'))
console.log(`It is now ${now.tz('America/New_York').format('ha')} Eastern`);
console.log(`It is now ${now.tz('America/Los_Angeles').format('ha')} Pacific`);
