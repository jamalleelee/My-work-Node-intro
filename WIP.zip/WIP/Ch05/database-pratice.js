const Promise = require("bluebird");
const knex = require("knex");
let db = knex(require("./knexfile"));

//Promise.try(() =>{
   // return db.schema.createTable("people",(table) =>{
       // table.increments("id").primary();
       // table.text("firstName");
       // table.text("lastName");
       // table.integer("age");
   // });
//}).then(() =>{
  //  console.log("Done!");
//}).finally(() =>{
    //db.destroy();
//});

Promise.try(() =>{
    return db("people").insert([
        {firstName: "John",lastName: "Smith", age:45 },
        {firstName: "Beth",lastName: "James", age:99 }]);
}).then(() => {
    console.log("Done!");
}).finally(() =>{
    db.destroy();
});