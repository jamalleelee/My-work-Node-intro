module.exports = {
    client: "pg",
    connection: {
        host: "localhost",
        user: "postgres",
        password: "password",
        database: "lab05"
    }
};