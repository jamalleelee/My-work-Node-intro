const tempArray = [
    { day: 'Sun', high: 80,low: 67 },
    { day: 'Mon', high: 75,low: 66 },
    { day: 'Tues', high: 90,low: 62 },
    { day: 'Wed', high: 95,low: 23 },
    { day: 'Thurs', high: 80,low: 11 },
    { day: 'Fri', high: 56,low: 17 },
    { day: 'Sat', high: 830,low: 54 }];

    let highestDay = tempArray[0];
    let lowestDay = tempArray[0];

    tempArray.forEach(element => {
        if(highestDay.high<element.high){
            highestDay=element;
        }
        if(lowestDay.low>element.low){
            lowestDay=element;
        }
    });

    console.log(`The lowest temp the week was ${lowestDay.day} and it was ${lowestDay.low}`)
    console.log(`The hightest temp the week was ${highestDay.day} and it was ${highestDay.low}`)