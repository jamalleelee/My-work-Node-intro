let firstName = 'Jamal';
let lastName = 'McDowell';

console.log(`Hello ${firstName} ${lastName}`);