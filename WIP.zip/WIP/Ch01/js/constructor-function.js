//function Person (firstName, lastName){
  //  this.firstName =firstName;
    //this.lastName = lastName;
    
   // let fullName = `${firstName} ${lastName}`;

    //return console.log(fullName);
//}

//let person1 = new Person("John", "Smith");
//console.log(person1);

function Person(fname, lname) {
    this.fname = fname;
    this.lname = lname;
    this.getFullName = function() {
        return `${fname} ${lname}`
    }
}

let person1 = new Person(firstName, lastName);
console.log(person1.getFullName());