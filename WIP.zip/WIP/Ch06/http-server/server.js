const http = require('http');
const server = http.createServer();

server.on('request', (request, response) => {
    response.end('Im sorry Ms. Galaxy!');
});

server.listen(3131, (err) => {  
    if (err) {
        return console.log('something bad happened', err);
    }

    console.log(`server is listening on 3131 http://localhost:3131`);
    })