const Promise = required("bluebird");
const fs = Promise.promisifyAll(require("fs"));

Promise.try(() =>{
    return fs.writeFileAsync()
}) {
    
} catch (error) {
    
}