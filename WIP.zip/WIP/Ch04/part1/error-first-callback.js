const fs = require('fs');

fs.readFile('input.txt', (err,data)=>{
    if(err){
        return console.error(err);
    }

    return console.log(data.toString())
} );