const Band = module.require('./constructor-band.js');
const beatles = new Band('The Beatles', ['John', 'Paul', 'George', 'Ringo']);
console.log(`beatles member count`, beatles.memberCount());
console.log(`Ringo is in the band? `, beatles.hasMember('Ringo'));
console.log(`Bingo is in the band? `, beatles.hasMember('Bingo'));
