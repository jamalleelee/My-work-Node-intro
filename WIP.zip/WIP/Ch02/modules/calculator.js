module.exports = class Calculator {

    add(a,b) {
        return a+b;
    }

    sub(a,b){
        return a-b;
    }

    mul(a,b){
        return a*b;
    }
}